using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.Networking;

public class WeatherManager : MonoBehaviour
{
    [SerializeField]
    Position position = new Position();

    public TextMeshProUGUI msg;

    public string url = "https://api.tomorrow.io/v4/weather/forecast";
    public string apikey = "9dh7UgYOnr2lhQYEedqkYtaUSP3NfQN1";

    public GameObject startBtn;
    public GameObject mainUI;

    public TextMeshProUGUI temp;
    public TextMeshProUGUI humidity;
    public TextMeshProUGUI windSpeed;

    public void OnClickGet()
    {
        if (Input.location.isEnabledByUser)
        {

            if (Input.location.status == LocationServiceStatus.Stopped)
            {
                Input.location.Start();
            }

            if (Input.location.status == LocationServiceStatus.Running)
            {
                position.lat = Input.location.lastData.latitude;
                position.lon = Input.location.lastData.longitude;

                msg.text = "Getting Data For \n" + position.ToString();

                StartCoroutine(GetWeather(position));
            }
        }
        else
        {
            msg.text = "Enable Location";
        }
    }


    IEnumerator GetWeather(Position position)
    {
        string str = $"{url}?location={position.lat},{position.lon}&apikey={apikey}";

        using (UnityWebRequest req = UnityWebRequest.Get(str))
        {
            yield return req.SendWebRequest();

            string json = req.downloadHandler.text;
            Res res = JsonUtility.FromJson<Res>(json);

            startBtn.SetActive(false);
            mainUI.SetActive(true);

            msg.text = "";

            temp.text = "Temperature: " + res.timelines.minutely[0].values.temperature.ToString() + " C";
            humidity.text = "Humidity: " + res.timelines.minutely[0].values.humidity.ToString() + " g/m3";
            windSpeed.text = "Wind Speed: " + res.timelines.minutely[0].values.windSpeed.ToString() + " m/s";
        }
    }

}

class Position
{
    public float lat;
    public float lon;

    public override string ToString()
    {
        return $"Lattitue: {lat} , Longitude: {lon}";
    }
}

[System.Serializable]
public class Res
{
    public Timeline timelines;
}

[System.Serializable]
public class Timeline
{
    public Minutely[] minutely;
}

[System.Serializable] 
public class Minutely
{
    public string time;
    public Values values;
}

[System.Serializable]
public class Values
{
    public float humidity;
    public float temperature;
    public float windSpeed;
}
